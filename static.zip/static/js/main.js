document.addEventListener('DOMContentLoaded', () => {
    const fileInput = document.getElementById('videoFile');
    const uploadForm = document.getElementById('uploadForm');
    const uploadBtn = document.getElementById('uploadBtn');
    const dropZone = document.getElementById('dropZone');
    const fileInfo = document.getElementById('fileInfo');
    const fileNameBadge = document.getElementById('fileNameBadge');
    
    // Upload Progress UI
    const uploadProgressContainer = document.getElementById('uploadProgressContainer');
    const uploadProgressBar = document.getElementById('uploadProgressBar');
    const uploadStatusText = document.getElementById('uploadStatusText');
    
    // Sections
    const analysisSection = document.getElementById('analysisSection');
    
    // Metadata UI
    const metaRes = document.getElementById('metaResolution');
    const metaSize = document.getElementById('metaSize');
    const metaDur = document.getElementById('metaDuration');
    const metaCodec = document.getElementById('metaCodec');
    
    // Recommendation UI
    const recCodec = document.getElementById('recCodec');
    const recCRF = document.getElementById('recCRF');
    const recSize = document.getElementById('recSize');
    const recRatio = document.getElementById('recRatio');
    const applyRecBtn = document.getElementById('applyRecBtn');
    
    // Action UI
    const modeBtns = document.querySelectorAll('.mode-btn');
    const startCompressBtn = document.getElementById('startCompressBtn');
    
    let currentUploadedFilename = '';
    let selectedMode = 'balanced';
    let currentMetadata = null;
    let recommendedSettings = null;

    if(fileInput) {
        fileInput.addEventListener('change', handleFileSelect);
        
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('dragover');
        });
        
        dropZone.addEventListener('dragleave', (e) => {
            e.preventDefault();
            dropZone.classList.remove('dragover');
        });
        
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('dragover');
            if (e.dataTransfer.files.length) {
                fileInput.files = e.dataTransfer.files;
                handleFileSelect();
            }
        });
        
        uploadForm.addEventListener('submit', uploadFile);
        applyRecBtn.addEventListener('click', applyRecommendation);
        startCompressBtn.addEventListener('click', startCompression);
        
        modeBtns.forEach(btn => {
            btn.addEventListener('click', (e) => {
                modeBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                selectedMode = btn.dataset.mode;
            });
        });
    }

    function handleFileSelect() {
        if(fileInput.files.length > 0) {
            const file = fileInput.files[0];
            fileNameBadge.textContent = file.name;
            fileInfo.classList.remove('d-none');
            uploadBtn.disabled = false;
        }
    }

    async function uploadFile(e) {
        e.preventDefault();
        
        const file = fileInput.files[0];
        if(!file) return;
        
        const formData = new FormData();
        formData.append('file', file);
        
        uploadBtn.disabled = true;
        uploadProgressContainer.classList.remove('d-none');
        
        // Use XMLHttpRequest for progress tracking
        const xhr = new XMLHttpRequest();
        
        xhr.upload.addEventListener("progress", (event) => {
            if (event.lengthComputable) {
                const percent = Math.round((event.loaded / event.total) * 100);
                uploadProgressBar.style.width = percent + '%';
                uploadStatusText.textContent = `Uploading... ${percent}%`;
            }
        });
        
        xhr.onload = async () => {
            if (xhr.status === 200) {
                const response = JSON.parse(xhr.responseText);
                uploadStatusText.textContent = "Upload complete. Analyzing video...";
                uploadProgressBar.classList.replace('bg-info', 'bg-success');
                
                currentUploadedFilename = response.filename;
                currentMetadata = response.metadata;
                
                // Display metadata
                metaRes.textContent = currentMetadata.resolution;
                metaSize.textContent = `${currentMetadata.size_mb} MB`;
                metaDur.textContent = currentMetadata.duration_formatted;
                metaCodec.textContent = currentMetadata.video_codec.toUpperCase();
                
                // Get prediction
                await fetchPrediction(currentMetadata);
                
                // Show Analysis Section
                analysisSection.classList.remove('d-none');
                startCompressBtn.disabled = false;
                
                // Select default mode button
                modeBtns.forEach(b => {
                    if(b.dataset.mode === 'balanced') b.classList.add('active');
                    else b.classList.remove('active');
                });
                
            } else {
                const response = JSON.parse(xhr.responseText);
                uploadStatusText.textContent = "Error: " + (response.error || "Upload failed");
                uploadProgressBar.classList.replace('bg-info', 'bg-danger');
                uploadBtn.disabled = false;
            }
        };
        
        xhr.onerror = () => {
            uploadStatusText.textContent = "Error connecting to server.";
            uploadProgressBar.classList.replace('bg-info', 'bg-danger');
            uploadBtn.disabled = false;
        };
        
        xhr.open("POST", "/upload");
        xhr.send(formData);
    }
    
    async function fetchPrediction(metadata) {
        try {
            const res = await fetch('/predict', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(metadata)
            });
            recommendedSettings = await res.json();
            
            recCodec.textContent = recommendedSettings.codec.replace('lib', '').toUpperCase();
            recCRF.textContent = recommendedSettings.crf;
            recSize.textContent = `${recommendedSettings.estimated_size_mb} MB`;
            recRatio.textContent = recommendedSettings.estimated_ratio;
            
        } catch(e) {
            console.error("Prediction error:", e);
        }
    }
    
    function applyRecommendation() {
        if(!recommendedSettings) return;
        
        selectedMode = 'custom';
        
        // Remove active from all preset buttons
        modeBtns.forEach(b => b.classList.remove('active'));
        
        // Show user feedback
        applyRecBtn.textContent = 'Applied!';
        applyRecBtn.classList.replace('btn-warning', 'btn-success');
        setTimeout(() => {
            applyRecBtn.textContent = 'Apply Recommended';
            applyRecBtn.classList.replace('btn-success', 'btn-warning');
        }, 2000);
    }
    
    async function startCompression() {
        startCompressBtn.disabled = true;
        startCompressBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Starting...';
        
        const payload = {
            filename: currentUploadedFilename,
            mode: selectedMode
        };
        
        if (selectedMode === 'custom' && recommendedSettings) {
            payload.codec = recommendedSettings.codec;
            payload.crf = recommendedSettings.crf;
        }
        
        try {
            const res = await fetch('/start_compression', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            const data = await res.json();
            
            if(data.history_id) {
                window.location.href = `/status.html?id=${data.history_id}`; // Redirect to processing page (will map route later)
                // wait, the processing page is just the route `/processing` but we didn't make a route for it.
                // Let's modify app.py or redirect to a specific URL. 
                // Ah, I see in app.py we don't have a /processing route! I need to add one, or just handle it differently.
                // Actually I will change the processing.html template above to be rendered via a route.
                
                // Let's redirect to an interim route we can add or just change the UI to show progress inline.
                // Or better, let's just make sure app.py has a route for rendering processing.html.
                window.location.href = `/processing?id=${data.history_id}`;
            } else {
                alert("Error starting compression");
                startCompressBtn.disabled = false;
                startCompressBtn.textContent = 'Start Compression';
            }
        } catch(e) {
            console.error(e);
            startCompressBtn.disabled = false;
            startCompressBtn.textContent = 'Start Compression';
        }
    }
});
