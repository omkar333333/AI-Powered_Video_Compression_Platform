import subprocess
import os

def compress_video(input_path, output_path, codec="h264_nvenc", crf=28, preset="fast", target_bitrate=None):
    """
    Compresses video using FFmpeg.
    Returns True if successful, False otherwise.
    """
    if not os.path.exists(input_path):
        return False, "Input file does not exist"

    # For audio, we use AAC, standard 128k
    cmd = [
        "ffmpeg",
        "-y", # Overwrite output files without asking
        "-i", input_path,
        "-c:v", codec
    ]

    if "nvenc" in codec:
        if target_bitrate:
            cmd.extend(["-rc", "vbr", "-cq", str(crf), "-b:v", str(target_bitrate), "-maxrate", str(target_bitrate), "-bufsize", str(target_bitrate * 2)])
        else:
            cmd.extend(["-rc", "vbr", "-cq", str(crf), "-b:v", "0"])
    else:
        if target_bitrate:
            cmd.extend(["-b:v", str(target_bitrate), "-maxrate", str(target_bitrate), "-bufsize", str(target_bitrate * 2)])
        else:
            cmd.extend(["-crf", str(crf)])

    cmd.extend([
        "-preset", preset,
        "-c:a", "aac",
        "-b:a", "128k",
        output_path
    ])

    try:
        # We capture output to check for errors, but since this is a long running task
        # in a real prod env, we might want to stream the output or use ffmpeg progress url.
        # For this prototype, we'll run it synchronously (it will be called in a background thread).
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        return True, "Compression successful"
    except subprocess.CalledProcessError as e:
        return False, f"FFmpeg error: {e.stderr}"
    except Exception as e:
        return False, str(e)
