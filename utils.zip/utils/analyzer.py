import subprocess
import json
import os

def analyze_video(filepath):
    """
    Extracts metadata from a video file using ffprobe.
    """
    if not os.path.exists(filepath):
        return {"error": "File does not exist"}

    cmd = [
        "ffprobe",
        "-v", "quiet",
        "-print_format", "json",
        "-show_format",
        "-show_streams",
        filepath
    ]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        data = json.loads(result.stdout)
        
        # Extract relevant info
        video_stream = next((stream for stream in data.get('streams', []) if stream.get('codec_type') == 'video'), None)
        audio_stream = next((stream for stream in data.get('streams', []) if stream.get('codec_type') == 'audio'), None)
        
        format_info = data.get('format', {})
        
        if not video_stream:
            return {"error": "No video stream found"}

        metadata = {
            "filename": os.path.basename(filepath),
            "size_bytes": int(format_info.get('size', 0)),
            "size_mb": round(int(format_info.get('size', 0)) / (1024 * 1024), 2),
            "duration": float(format_info.get('duration', 0)),
            "bitrate": int(format_info.get('bit_rate', 0)) if format_info.get('bit_rate') else 0,
            "width": int(video_stream.get('width', 0)),
            "height": int(video_stream.get('height', 0)),
            "video_codec": video_stream.get('codec_name', 'unknown'),
            "audio_codec": audio_stream.get('codec_name', 'none') if audio_stream else 'none',
            "fps": eval(video_stream.get('r_frame_rate', '0/1')) # r_frame_rate is often a string like "30000/1001"
        }
        
        metadata["resolution"] = f"{metadata['width']}x{metadata['height']}"
        
        # Format duration to HH:MM:SS
        hours = int(metadata['duration'] // 3600)
        minutes = int((metadata['duration'] % 3600) // 60)
        seconds = int(metadata['duration'] % 60)
        metadata['duration_formatted'] = f"{hours:02d}:{minutes:02d}:{seconds:02d}"
        
        return metadata

    except subprocess.CalledProcessError as e:
        return {"error": f"ffprobe error: {e.stderr}"}
    except Exception as e:
        return {"error": str(e)}

if __name__ == "__main__":
    # Test block
    print(analyze_video("test.mp4"))
