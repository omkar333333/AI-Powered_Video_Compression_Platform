def predict_best_settings(metadata):
    """
    Predicts optimal compression settings based on video metadata.
    Simple rule-based for now.
    """
    if "error" in metadata:
        return {"error": metadata["error"]}

    height = metadata.get("height", 0)
    size_mb = metadata.get("size_mb", 0)
    duration = metadata.get("duration", 0)
    
    # Defaults
    codec = "hevc_nvenc" # Prefer H.265 hardware encoding for blazing fast speeds AND better compression
    crf = 28 # Balanced
    preset = "fast"
    
    # Logic based on resolution
    if height >= 2160: # 4K
        crf = 28
    elif height >= 1080: # 1080p
        crf = 26
    elif height >= 720: # 720p
        crf = 24
    else:
        crf = 22 # Lower res needs lower CRF to maintain quality
        codec = "libx264" # H.264 might be better/faster for smaller vids
        
    # Logic based on bitrate/size (estimate output size)
    # A rough estimate for CRF 28 H.265 is about 1.5 - 2.5 Mbps for 1080p
    # Let's do a simple calculation based on typical compression ratios.
    
    estimated_ratio = 0.5 # Default to 50%
    if codec == "libx265":
        if crf <= 24:
            estimated_ratio = 0.7
        elif crf <= 28:
            estimated_ratio = 0.5
        else:
            estimated_ratio = 0.3
    else:
        if crf <= 24:
            estimated_ratio = 0.8
        elif crf <= 28:
            estimated_ratio = 0.6
        else:
            estimated_ratio = 0.4
            
    estimated_size_mb = size_mb * estimated_ratio
    
    return {
        "codec": codec,
        "crf": crf,
        "preset": preset,
        "estimated_size_mb": round(estimated_size_mb, 2),
        "estimated_ratio": round(estimated_ratio * 100, 2)
    }
