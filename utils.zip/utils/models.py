from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class CompressionHistory(db.Model):
    __tablename__ = 'compression_history'
    
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(255), nullable=False)
    original_size = db.Column(db.Float, nullable=False) # In MB
    compressed_size = db.Column(db.Float, nullable=True) # In MB
    ratio = db.Column(db.Float, nullable=True) # Percentage
    compression_mode = db.Column(db.String(50), nullable=False)
    processing_time = db.Column(db.Float, nullable=True) # In seconds
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(50), default='processing') # processing, completed, failed
    
    def to_dict(self):
        return {
            'id': self.id,
            'filename': self.filename,
            'original_size': self.original_size,
            'compressed_size': self.compressed_size,
            'ratio': self.ratio,
            'compression_mode': self.compression_mode,
            'processing_time': self.processing_time,
            'created_at': self.created_at.isoformat(),
            'status': self.status
        }
